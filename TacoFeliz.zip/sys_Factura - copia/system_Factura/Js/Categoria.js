﻿ //<reference path=C: \ Users\ rey padilla\ source\ repos\ sys_Factura\ system_Factura\ Views\Producto\Create.cshtml" />
$("#btnNuevo").click(function (eve) {
    $("#modal-content").load("/Producto/Create");
});